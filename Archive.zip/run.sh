#!/bin/bash
echo "✨ Starting Tarot Teller application...✨"
echo "🔮 Open your browser and navigate to http://localhost:5000 🔮"
echo "💫 Hover over cards to see their meanings 💫"
python app.py
